/* Questo programma implementa l'Utente 1, che deve partire
dopo il programma che implementa Utente 2
Questo programma utilizza la Memoria Condivisa e 
i Semafori gia' creati dal secondo utente.
Utente 1 chiede all�utente se vuole continuare; nel caso in cui l�utente non voglia continuare deve inserire la parola �fine�, 
che verr� scritta nel campo stringa dello struct condiviso tra i due processi. 
L�inserimento di questa stringa comporta la fine del primo processo e, visto che lo struct � condiviso tra i due processi, anche il secondo processo termina quando legge il valore �fine� all�interno dello struct condiviso.
Nel caso in cui Utente 1 non voglia terminare, esso apre il file �output� e se esso contiene elementi (alla prima esecuzione non conterr� nulla ovviamente), devono essere tutti letti (a partire dall�inizio del file fino alla fine del file) e stampati a video. Poi il primo processo riempie in modo casuale il vettore di 10 elementi contenuto nello struct condiviso, e passa il turno al secondo processo.

*/	

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include "Semafori.h" //Contiene l'implementazione dei semafori
#include<fcntl.h>


#define SHM_KEY (key_t)1234 /* Key usata per la shared memory */
#define SEM_KEY1 (key_t)5678 /* Key usata per il semaforo SEM_USER_1*/
#define SEM_KEY2 (key_t)9012 /* Key usata per il semaforo SEM_USER_2*/

#define TEXT_SIZE 11
#define VETT_SIZE 10
#define FILE "output"

typedef struct {
  float v[VETT_SIZE];
  char text[TEXT_SIZE]; //Stringa 
} info;


int main(void) {
    int result, i,continua = 1;
    int fd; //descrittore di file
    int ShmID; // ID della Shared memory.
    int SEM_USER_1, SEM_USER_2; // IDs dei due Semafori.
    void *ShmP = (void *)0;
    info * p; // Indirizzo della Shared memory.
	
    printf("Benvenuti ! Digita 'fine' per terminare. Digita qualunque altra cosa per continuare. \n");
		
    ShmID = shmget(SHM_KEY, TEXT_SIZE, 0666 | IPC_CREAT);
    if (ShmID == -1) {
         fprintf(stderr, "shmget failed\n");
         exit(EXIT_FAILURE);
    }
    ShmP = shmat(ShmID, (void *)0, 0); 
    if (ShmP == (void *)-1) {
         fprintf(stderr, "shmat failed\n");
         exit(EXIT_FAILURE);
    }
    p = (info *)ShmP;
		       
    SEM_USER_1 = semget(SEM_KEY1, 1, 0666 | IPC_CREAT); 
    if (SEM_USER_1 == -1) {
         fprintf(stderr, "semget SEM_USER_1 failed\n");
         exit(EXIT_FAILURE);
    }
    SEM_USER_2 = semget(SEM_KEY2, 1, 0666 | IPC_CREAT); 
    if (SEM_USER_2 == -1) {
         fprintf(stderr, "semget SEM_USER_2 failed\n");
         exit(EXIT_FAILURE);
    }
      
    printf("Tu sei l'Utente 1 \n");
 
    while (continua) {
      if (SEM_P(SEM_USER_1)==-1) exit(EXIT_FAILURE);
      // L'altro utente vuole terminare ?
      if (strncmp(p->text, "fine", 4) == 0) continua=0;
      else {
         fd=open(FILE, O_RDONLY);
         if (fd==-1) {
              fprintf(stderr, "Errore Apertura File\n");
              exit(EXIT_FAILURE);
         }
         i=0;
         printf("Il file che ho ricevuto contiene i seguenti elementi \n");
         do { 
             result=read(fd,&p->v[i],sizeof(float));
             if (result) printf("\nv[%d]=%f ",i,p->v[i]);
             i++; 
         } while (result>0); 
         close(fd);

         printf("\nSto riempendo il vettore\n");
         for (i=0; i<VETT_SIZE; i++) {
                p->v[i]=rand()%10;
                printf("v[%d]=%f \n",i,p->v[i]);
         }

   	 // Vuoi terminare ?
	 printf("Inserisci 'fine' per finire > ");
	 fgets(p->text, TEXT_SIZE, stdin);
         if (strncmp(p->text, "fine", 4) == 0) continua=0;
      }	
      if (SEM_V(SEM_USER_2)==-1) exit(EXIT_FAILURE);
    }
		             
    if (shmdt(ShmP) == -1) {
        fprintf(stderr, "shmdt failed\n");
        exit(EXIT_FAILURE);
    }
    exit(EXIT_SUCCESS);
}

