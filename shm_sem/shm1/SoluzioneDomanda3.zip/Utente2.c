/*Si tratta dell'Utente 2, che parte per prima e deve 
creare la Memoria Condivisa e i Semafori.
Utente 2 legge il campo stringa dello struct condiviso e se contiene il valore �fine�, termina. 
Altrimenti, legge tutto il vettore dello struct condiviso e scrive tutti gli elementi nel file di nome �output�. 
Si suppone che il secondo processo apra il file con l�opzione O_TRUNC in modo da svuotarne il contenuto e riempirlo ex novo. 
Il file viene cos� riempito di tutti i 10 elementi contenuti nel vettore condiviso.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include "Semafori.h" //Contiene l'implementazione dei semafori
#include<fcntl.h> //serve per le costanti della open()


#define SHM_KEY (key_t)1234 /* Key usata per la shared memory */
#define SEM_KEY1 (key_t)5678 /* Key usata per il semaforo SEM_USER_1*/
#define SEM_KEY2 (key_t)9012 /* Key usata per il semaforo SEM_USER_2*/

#define TEXT_SIZE 11
#define VETT_SIZE 10
#define FILE "output"

typedef struct {
  float v[VETT_SIZE];
  char text[TEXT_SIZE]; //Stringa 
} info;


int main(void) {
    int i, continua = 1;
    int fd; //descrittore file
    int ShmID; // ID della Shared memory.
    int SEM_USER_1, SEM_USER_2; // IDs dei due Semafori.
    void * ShmP = (void *)0;
    info * p; // Indirizzo della Shared memory.
    
    printf("Benvenuti ! Digita 'fine' per terminare. Digita qualunque altra cosa per continuare. \n");

    ShmID = shmget(SHM_KEY, TEXT_SIZE, 0666 | IPC_CREAT);
    if (ShmID == -1) {
        fprintf(stderr, "shmget failed\n");
        exit(EXIT_FAILURE);
    }
    ShmP = shmat(ShmID, (void *)0, 0); 
    if (ShmP == (void *)-1) {
        fprintf(stderr, "shmat failed\n");
        exit(EXIT_FAILURE);
    }
    p = (info *)ShmP;

    sprintf(p->text, ""); //Il processo inizializza il campo text a una stringa vuota
    //Il processo crea un file vuoto
    fd=open(FILE, O_RDWR | O_TRUNC | O_CREAT, 0660);
    if (fd==-1) {
               fprintf(stderr, "Errore Apertura File\n");
               exit(EXIT_FAILURE);
    } 
    close(fd);
 
    //Il processo crea i due semafori
    SEM_USER_1 = semget(SEM_KEY1, 1, 0666 | IPC_CREAT); 
    if (SEM_USER_1 == -1) {
        fprintf(stderr, "semget SEM_USER_1 failed\n");
        exit(EXIT_FAILURE);
    }
    SEM_USER_2 = semget(SEM_KEY2, 1, 0666 | IPC_CREAT); 
    if (SEM_USER_2 == -1) {
        fprintf(stderr, "semget SEM_USER_2 failed\n");
        exit(EXIT_FAILURE);
    }

    //Il processo setta i semafori
    if (SEM_SET(SEM_USER_2, 0)==-1) exit(EXIT_FAILURE); 
    if (SEM_SET(SEM_USER_1, 1)==-1) exit(EXIT_FAILURE); 

    printf("Tu sei l'Utente 2 \n");

    while (continua) {
        if (SEM_P(SEM_USER_2)==-1) exit(EXIT_FAILURE);
        //L'altro utente vuole terminare ?
        if (strncmp(p->text, "fine", 4) == 0) continua=0;
        else {
           // Apre il file e riversa tutto il vettore in esso.
 
          fd=open(FILE, O_WRONLY | O_CREAT | O_TRUNC, 0660);
          if (fd==-1) {
               fprintf(stderr, "Errore Apertura File\n");
               exit(EXIT_FAILURE);
          }
          for (i=0; i<VETT_SIZE; i++) 
                         write(fd,&p->v[i],sizeof(float));
          close(fd);
          printf("Ho riversato il vettore nel file");
	  // Vuoi terminare ?
	  printf("Inserisci 'fine' per finire > ");
	  fgets(p->text, TEXT_SIZE, stdin);
          if (strncmp(p->text, "fine", 4) == 0) continua=0;
	}
        if (SEM_V(SEM_USER_1)==-1) exit(EXIT_FAILURE);
     }
	// Visto che sei il secondo utente, devi distruggere 
	// il semaforo e la memoria condivisa.
     if (shmdt(ShmP) == -1) {
            fprintf(stderr, "shmdt failed\n");
            exit(EXIT_FAILURE);
     }
     if (shmctl(ShmID, IPC_RMID, 0) == -1) {
            fprintf(stderr, "shmctl(IPC_RMID) failed\n");
            exit(EXIT_FAILURE);
     }	            
     SEM_DEL(SEM_USER_1);
     SEM_DEL(SEM_USER_2);
	           
     exit(EXIT_SUCCESS);
}

